Development moved to https://gitlab.com/blacknet-ninja

https://vedra.org/ aims to continue on Vedra chain.
